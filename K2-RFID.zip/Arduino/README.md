# Arduino
<br>

<a href=https://github.com/DnG-Crafts/K2-RFID/tree/main/Arduino/ESP32>Code for ESP32 boards</a><br><br>

<a href=https://github.com/DnG-Crafts/K2-RFID/tree/main/Arduino/ESP8266>Code for ESP8266 boards</a><br><br>

<a href=https://github.com/DnG-Crafts/K2-RFID/tree/main/Arduino/Pico_W>Code for Pico W boards</a>


<br><br>

Default Access point information:<br>
```
SSID:    K2_RFID
PASS:    password
Web URL: http://10.1.0.1 or http://k2.local
```
<br><br>

Flash Code:

[![https://www.youtube.com/watch?v=WOznbT7NbWI](https://img.youtube.com/vi/WOznbT7NbWI/0.jpg)](https://www.youtube.com/watch?v=WOznbT7NbWI)

https://www.youtube.com/watch?v=WOznbT7NbWI<br>


