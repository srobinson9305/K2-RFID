package dngsoftware.spoolid;

public class jsonItem {
       public String jKey;
       public Object jValue;
       public String hintValue;
}
