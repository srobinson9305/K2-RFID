# Windows
<br>

This was tested using the <a href=https://www.acs.com.hk/en/products/3/acr122u-usb-nfc-reader/>ACR122U</a> reader.
<br><br>
A compiled copy can be downloaded from the <a href=https://github.com/DnG-Crafts/K2-RFID/releases>releases</a> page.
<br><br><br>
Compiled with <a href=https://visualstudio.microsoft.com/vs/community/>Visual Studio</a>



<br><br>

<img src=https://github.com/DnG-Crafts/K2-RFID/blob/main/Windows/winapp.jpg>
