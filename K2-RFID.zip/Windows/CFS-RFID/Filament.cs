﻿public class Filament
{
    public string FilamentName { get; set; }
    public string FilamentId { get; set; }
    public string FilamentVendor { get; set; }
    public string FilamentType { get; set; }
    public string FilamentParam { get; set; }
}